//this takes in the animal and sound
public class Animal {
	private String type;
	private String sound;
	public void setType(String animal_type)
		{
			type=animal_type;
		}
	public void setSound(String animal_sound)
		{
			sound=animal_sound;
		}
	public String getType()
	{
		return(type);
	}
	public String getSound()
	{
		return(sound);
	}
}